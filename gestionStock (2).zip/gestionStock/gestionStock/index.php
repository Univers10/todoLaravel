<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Requête pour compter le nombre de produits
$stmt = $connexion->query("SELECT COUNT(*) as nb_produits FROM produits");
$nb_produits = $stmt->fetch()['nb_produits'];

// Requête pour compter le nombre de clients
$stmt = $connexion->query("SELECT COUNT(*) as nb_clients FROM clients");
$nb_clients = $stmt->fetch()['nb_clients'];

// Requête pour compter le nombre de commandes
$stmt = $connexion->query("SELECT COUNT(*) as nb_commandes FROM commandes");
$nb_commandes = $stmt->fetch()['nb_commandes'];

// Requête pour compter les produits à faible stock
$stmt = $connexion->query("SELECT COUNT(*) as nb_faible_stock FROM produits WHERE quantite <= seuil_alerte");
$nb_faible_stock = $stmt->fetch()['nb_faible_stock'];

// Requête pour récupérer les produits à faible stock
$stmt = $connexion->query("SELECT * FROM produits WHERE quantite <= seuil_alerte ORDER BY quantite ASC LIMIT 5");
$produits_faible_stock = $stmt->fetchAll();

// Requête pour récupérer les dernières commandes
$stmt = $connexion->query("
    SELECT c.id, c.reference, c.date_commande, c.statut, c.montant_total, cl.nom as client
    FROM commandes c
    JOIN clients cl ON c.client_id = cl.id
    ORDER BY c.date_commande DESC
    LIMIT 5
");
$dernieres_commandes = $stmt->fetchAll();

// Requête pour récupérer les meilleurs clients
$stmt = $connexion->query("
    SELECT cl.id, cl.nom, cl.type, COUNT(c.id) as nb_commandes, SUM(c.montant_total) as montant_total
    FROM clients cl
    JOIN commandes c ON cl.id = c.client_id
    GROUP BY cl.id
    ORDER BY montant_total DESC
    LIMIT 3
");
$meilleurs_clients = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Gestion de Stock</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --light: #f8fafc;
            --dark: #1e293b;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f1f5f9;
            color: var(--dark);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: var(--dark);
            color: white;
            padding: 1rem;
        }
        
        .sidebar-header {
            padding: 1rem 0;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 1rem;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            margin-bottom: 0.5rem;
        }
        
        .sidebar-menu a {
            display: block;
            padding: 0.75rem 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 0.25rem;
            transition: all 0.3s ease;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            padding: 1rem;
            overflow-y: auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .header h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        /* Card */
        .card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
        }
        
        /* Grid */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0.5rem 0;
        }
        
        .stat-number.text-primary {
            color: var(--primary);
        }
        
        .stat-number.text-success {
            color: var(--success);
        }
        
        .stat-number.text-warning {
            color: var(--warning);
        }
        
        .stat-number.text-danger {
            color: var(--danger);
        }
        
        /* Table */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead th {
            background-color: #f8fafc;
            text-align: left;
            padding: 0.75rem;
            font-weight: 600;
        }
        
        tbody td {
            padding: 0.75rem;
            border-top: 1px solid #e2e8f0;
        }
        
        tbody tr:hover {
            background-color: #f1f5f9;
        }
        
        /* Badges */
        .badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-success {
            background-color: #dcfce7;
            color: #16a34a;
        }
        
        .badge-warning {
            background-color: #fef3c7;
            color: #d97706;
        }
        
        .badge-danger {
            background-color: #fee2e2;
            color: #dc2626;
        }
        
        /* Buttons */
        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            font-weight: 500;
            text-align: center;
            border: none;
            border-radius: 0.25rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                margin-bottom: 1rem;
            }
            
            .grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>GestionStock</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php" class="active">Tableau de bord</a></li>
                <li><a href="produits.php">Produits</a></li>
                <li><a href="clients.php">Clients</a></li>
                <li><a href="commandes.php">Commandes</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Tableau de bord</h1>
                <a href="index.php" class="btn btn-primary">Actualiser</a>
            </div>
            
            <!-- Stats Cards -->
            <div class="grid">
                <div class="stat-card">
                    <h3>Produits</h3>
                    <div class="stat-number text-primary"><?php echo $nb_produits; ?></div>
                    <a href="produits.php">Gérer les produits</a>
                </div>
                <div class="stat-card">
                    <h3>Clients</h3>
                    <div class="stat-number text-success"><?php echo $nb_clients; ?></div>
                    <a href="clients.php">Gérer les clients</a>
                </div>
                <div class="stat-card">
                    <h3>Commandes</h3>
                    <div class="stat-number text-warning"><?php echo $nb_commandes; ?></div>
                    <a href="commandes.php">Gérer les commandes</a>
                </div>
                <div class="stat-card">
                    <h3>Stock faible</h3>
                    <div class="stat-number text-danger"><?php echo $nb_faible_stock; ?></div>
                    <a href="#faible-stock">Voir détails</a>
                </div>
            </div>
            
            <!-- Low Stock Alert -->
            <div class="card" id="faible-stock">
                <div class="card-header">
                    <div class="card-title">Produits à faible stock</div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Catégorie</th>
                            <th>Quantité</th>
                            <th>Seuil d'alerte</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($produits_faible_stock)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center;">Aucun produit à faible stock.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($produits_faible_stock as $produit): ?>
                                <tr>
                                    <td><?php echo $produit['id']; ?></td>
                                    <td><?php echo htmlspecialchars($produit['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($produit['categorie']); ?></td>
                                    <td>
                                        <?php if ($produit['quantite'] == 0): ?>
                                            <span class="badge badge-danger"><?php echo $produit['quantite']; ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-warning"><?php echo $produit['quantite']; ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $produit['seuil_alerte']; ?></td>
                                    <td>
                                        <a href="produit_edit.php?id=<?php echo $produit['id']; ?>" class="btn btn-primary">Réapprovisionner</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Recent Orders -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Commandes récentes</div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Référence</th>
                            <th>Client</th>
                            <th>Date</th>
                            <th>Montant</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($dernieres_commandes)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center;">Aucune commande récente.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($dernieres_commandes as $commande): ?>
                                <tr>
                                    <td><?php echo $commande['id']; ?></td>
                                    <td><?php echo htmlspecialchars($commande['reference']); ?></td>
                                    <td><?php echo htmlspecialchars($commande['client']); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($commande['date_commande'])); ?></td>
                                    <td><?php echo number_format($commande['montant_total'], 2, ',', ' '); ?> €</td>
                                    <td>
                                        <?php
                                        $statut_class = '';
                                        switch ($commande['statut']) {
                                            case 'en_attente':
                                                $statut_class = 'badge-warning';
                                                $statut_text = 'En attente';
                                                break;
                                            case 'en_cours':
                                                $statut_class = 'badge-warning';
                                                $statut_text = 'En cours';
                                                break;
                                            case 'expediee':
                                                $statut_class = 'badge-primary';
                                                $statut_text = 'Expédiée';
                                                break;
                                            case 'livree':
                                                $statut_class = 'badge-success';
                                                $statut_text = 'Livrée';
                                                break;
                                            case 'annulee':
                                                $statut_class = 'badge-danger';
                                                $statut_text = 'Annulée';
                                                break;
                                            default:
                                                $statut_class = '';
                                                $statut_text = $commande['statut'];
                                        }
                                        ?>
                                        <span class="badge <?php echo $statut_class; ?>"><?php echo $statut_text; ?></span>
                                    </td>
                                    <td>
                                        <a href="commande_details.php?id=<?php echo $commande['id']; ?>" class="btn btn-primary">Détails</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Top Clients -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Meilleurs clients</div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Type</th>
                            <th>Commandes</th>
                            <th>Montant total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($meilleurs_clients)): ?>
                            <tr>
                                <td colspan="5" style="text-align: center;">Aucun client enregistré.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($meilleurs_clients as $client): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($client['nom']); ?></td>
                                    <td><?php echo ($client['type'] == 'entreprise') ? 'Entreprise' : 'Particulier'; ?></td>
                                    <td><?php echo $client['nb_commandes']; ?></td>
                                    <td><?php echo number_format($client['montant_total'], 2, ',', ' '); ?> €</td>
                                    <td>
                                        <a href="client_details.php?id=<?php echo $client['id']; ?>" class="btn btn-primary">Profil</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html> 