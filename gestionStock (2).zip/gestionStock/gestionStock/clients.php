<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Définir le titre de la page
$titre = "Gestion des Clients";

// Traitement de la suppression d'un client
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    try {
        // Vérifier si le client existe
        $stmt = $connexion->prepare("SELECT * FROM clients WHERE id = ?");
        $stmt->execute([$id]);
        $client = $stmt->fetch();
        
        if ($client) {
            // Vérifier si le client a des commandes associées
            $stmt = $connexion->prepare("SELECT COUNT(*) as nb_commandes FROM commandes WHERE client_id = ?");
            $stmt->execute([$id]);
            $nb_commandes = $stmt->fetch()['nb_commandes'];
            
            if ($nb_commandes > 0) {
                // Message d'erreur si le client a des commandes
                $_SESSION['message'] = "Impossible de supprimer ce client car il a $nb_commandes commande(s) associée(s).";
                $_SESSION['message_type'] = "warning";
            } else {
                // Supprimer le client
                $stmt = $connexion->prepare("DELETE FROM clients WHERE id = ?");
                $stmt->execute([$id]);
                
                // Message de succès
                $_SESSION['message'] = "Le client a été supprimé avec succès.";
                $_SESSION['message_type'] = "success";
            }
        } else {
            // Message d'erreur si le client n'existe pas
            $_SESSION['message'] = "Client introuvable.";
            $_SESSION['message_type'] = "danger";
        }
    } catch (PDOException $e) {
        // Message d'erreur en cas d'échec de la suppression
        $_SESSION['message'] = "Erreur lors de la suppression du client : " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }
    
    // Rediriger pour éviter la soumission du formulaire en cas de rafraîchissement de la page
    header("Location: clients.php");
    exit;
}

// Traitement de la recherche
$search = isset($_GET['search']) ? $_GET['search'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';

// Construction de la requête avec les filtres
$sql = "SELECT * FROM clients WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (nom LIKE ? OR email LIKE ? OR telephone LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($type)) {
    $sql .= " AND type = ?";
    $params[] = $type;
}

$sql .= " ORDER BY id DESC";

// Exécuter la requête
$stmt = $connexion->prepare($sql);
$stmt->execute($params);
$clients = $stmt->fetchAll();

// Inclure l'en-tête
require_once 'includes/header.php';
?>

<!-- Contenu principal -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Liste des Clients</h2>
        <a href="client_add.php" class="btn">Ajouter un client</a>
    </div>
    
    <!-- Formulaire de recherche et filtres -->
    <form action="clients.php" method="GET" class="mb-2">
        <div class="grid">
            <div class="form-group">
                <label for="search" class="form-label">Recherche</label>
                <input type="text" id="search" name="search" class="form-control" placeholder="Nom, email ou téléphone" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="form-group">
                <label for="type" class="form-label">Type de client</label>
                <select id="type" name="type" class="form-control">
                    <option value="">Tous les types</option>
                    <option value="particulier" <?php echo $type === 'particulier' ? 'selected' : ''; ?>>Particulier</option>
                    <option value="entreprise" <?php echo $type === 'entreprise' ? 'selected' : ''; ?>>Entreprise</option>
                </select>
            </div>
            <div class="form-group" style="display: flex; align-items: flex-end;">
                <button type="submit" class="btn">Filtrer</button>
                <a href="clients.php" class="btn btn-secondary" style="margin-left: 0.5rem;">Réinitialiser</a>
            </div>
        </div>
    </form>
    
    <!-- Tableau des clients -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Type</th>
                <th>Email</th>
                <th>Téléphone</th>
                <th>Date de création</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($clients) > 0): ?>
                <?php foreach ($clients as $client): ?>
                    <tr>
                        <td><?php echo $client['id']; ?></td>
                        <td><?php echo htmlspecialchars($client['nom']); ?></td>
                        <td>
                            <?php if ($client['type'] === 'particulier'): ?>
                                <span class="badge badge-success">Particulier</span>
                            <?php else: ?>
                                <span class="badge badge-warning">Entreprise</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($client['email'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($client['telephone'] ?? '-'); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($client['date_creation'])); ?></td>
                        <td>
                            <a href="client_edit.php?id=<?php echo $client['id']; ?>" class="btn btn-secondary">Modifier</a>
                            <a href="clients.php?delete=<?php echo $client['id']; ?>" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce client ?');">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">Aucun client trouvé</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
// Inclure le pied de page
require_once 'includes/footer.php';
?> 