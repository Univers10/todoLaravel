<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Définir le titre de la page
$titre = "Gestion des Commandes";

// Traitement de la suppression d'une commande
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    try {
        // Vérifier si la commande existe
        $stmt = $connexion->prepare("SELECT * FROM commandes WHERE id = ?");
        $stmt->execute([$id]);
        $commande = $stmt->fetch();
        
        if ($commande) {
            // Supprimer les produits de la commande
            $stmt = $connexion->prepare("DELETE FROM commande_produits WHERE commande_id = ?");
            $stmt->execute([$id]);
            
            // Supprimer la commande
            $stmt = $connexion->prepare("DELETE FROM commandes WHERE id = ?");
            $stmt->execute([$id]);
            
            // Message de succès
            $_SESSION['message'] = "La commande a été supprimée avec succès.";
            $_SESSION['message_type'] = "success";
        } else {
            // Message d'erreur si la commande n'existe pas
            $_SESSION['message'] = "Commande introuvable.";
            $_SESSION['message_type'] = "danger";
        }
    } catch (PDOException $e) {
        // Message d'erreur en cas d'échec de la suppression
        $_SESSION['message'] = "Erreur lors de la suppression de la commande : " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }
    
    // Rediriger pour éviter la soumission du formulaire en cas de rafraîchissement de la page
    header("Location: commandes.php");
    exit;
}

// Traitement de la recherche et des filtres
$search = isset($_GET['search']) ? $_GET['search'] : '';
$client = isset($_GET['client']) ? $_GET['client'] : '';
$statut = isset($_GET['statut']) ? $_GET['statut'] : '';
$date_debut = isset($_GET['date_debut']) ? $_GET['date_debut'] : '';
$date_fin = isset($_GET['date_fin']) ? $_GET['date_fin'] : '';

// Construction de la requête avec les filtres
$sql = "
    SELECT c.*, cl.nom as client_nom 
    FROM commandes c
    JOIN clients cl ON c.client_id = cl.id
    WHERE 1=1
";
$params = [];

if (!empty($search)) {
    $sql .= " AND (c.reference LIKE ? OR cl.nom LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($client)) {
    $sql .= " AND c.client_id = ?";
    $params[] = $client;
}

if (!empty($statut)) {
    $sql .= " AND c.statut = ?";
    $params[] = $statut;
}

if (!empty($date_debut)) {
    $sql .= " AND c.date_commande >= ?";
    $params[] = $date_debut;
}

if (!empty($date_fin)) {
    $sql .= " AND c.date_commande <= ?";
    $params[] = $date_fin;
}

$sql .= " ORDER BY c.date_commande DESC";

// Exécuter la requête
$stmt = $connexion->prepare($sql);
$stmt->execute($params);
$commandes = $stmt->fetchAll();

// Récupérer tous les clients pour le filtre
$stmt = $connexion->query("SELECT id, nom FROM clients ORDER BY nom");
$clients = $stmt->fetchAll();

// Inclure l'en-tête
require_once 'includes/header.php';
?>

<!-- Contenu principal -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Liste des Commandes</h2>
        <a href="commande_add.php" class="btn">Ajouter une commande</a>
    </div>
    
    <!-- Formulaire de recherche et filtres -->
    <form action="commandes.php" method="GET" class="mb-2">
        <div class="grid" style="grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));">
            <div class="form-group">
                <label for="search" class="form-label">Recherche</label>
                <input type="text" id="search" name="search" class="form-control" placeholder="Référence ou client" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="form-group">
                <label for="client" class="form-label">Client</label>
                <select id="client" name="client" class="form-control">
                    <option value="">Tous les clients</option>
                    <?php foreach ($clients as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo $client == $c['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($c['nom']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="statut" class="form-label">Statut</label>
                <select id="statut" name="statut" class="form-control">
                    <option value="">Tous les statuts</option>
                    <option value="en_attente" <?php echo $statut === 'en_attente' ? 'selected' : ''; ?>>En attente</option>
                    <option value="en_cours" <?php echo $statut === 'en_cours' ? 'selected' : ''; ?>>En cours</option>
                    <option value="expediee" <?php echo $statut === 'expediee' ? 'selected' : ''; ?>>Expédiée</option>
                    <option value="livree" <?php echo $statut === 'livree' ? 'selected' : ''; ?>>Livrée</option>
                    <option value="annulee" <?php echo $statut === 'annulee' ? 'selected' : ''; ?>>Annulée</option>
                </select>
            </div>
            <div class="form-group">
                <label for="date_debut" class="form-label">Date début</label>
                <input type="date" id="date_debut" name="date_debut" class="form-control" value="<?php echo htmlspecialchars($date_debut); ?>">
            </div>
            <div class="form-group">
                <label for="date_fin" class="form-label">Date fin</label>
                <input type="date" id="date_fin" name="date_fin" class="form-control" value="<?php echo htmlspecialchars($date_fin); ?>">
            </div>
            <div class="form-group" style="display: flex; align-items: flex-end;">
                <button type="submit" class="btn">Filtrer</button>
                <a href="commandes.php" class="btn btn-secondary" style="margin-left: 0.5rem;">Réinitialiser</a>
            </div>
        </div>
    </form>
    
    <!-- Tableau des commandes -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Référence</th>
                <th>Client</th>
                <th>Date</th>
                <th>Statut</th>
                <th>Montant</th>
                <th>Paiement</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($commandes) > 0): ?>
                <?php foreach ($commandes as $commande): ?>
                    <tr>
                        <td><?php echo $commande['id']; ?></td>
                        <td><?php echo htmlspecialchars($commande['reference']); ?></td>
                        <td><?php echo htmlspecialchars($commande['client_nom']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($commande['date_commande'])); ?></td>
                        <td>
                            <?php 
                            $statut_classe = '';
                            $statut_texte = '';
                            switch ($commande['statut']) {
                                case 'en_attente':
                                    $statut_classe = 'badge-warning';
                                    $statut_texte = 'En attente';
                                    break;
                                case 'en_cours':
                                    $statut_classe = 'badge-warning';
                                    $statut_texte = 'En cours';
                                    break;
                                case 'expediee':
                                    $statut_classe = 'badge-primary';
                                    $statut_texte = 'Expédiée';
                                    break;
                                case 'livree':
                                    $statut_classe = 'badge-success';
                                    $statut_texte = 'Livrée';
                                    break;
                                case 'annulee':
                                    $statut_classe = 'badge-danger';
                                    $statut_texte = 'Annulée';
                                    break;
                            }
                            ?>
                            <span class="badge <?php echo $statut_classe; ?>">
                                <?php echo $statut_texte; ?>
                            </span>
                        </td>
                        <td><?php echo number_format($commande['montant_total'], 2, ',', ' ') . ' €'; ?></td>
                        <td>
                            <?php if ($commande['methode_paiement']): ?>
                                <?php 
                                $methode_paiement = '';
                                switch ($commande['methode_paiement']) {
                                    case 'carte':
                                        $methode_paiement = 'Carte bancaire';
                                        break;
                                    case 'virement':
                                        $methode_paiement = 'Virement';
                                        break;
                                    case 'cheque':
                                        $methode_paiement = 'Chèque';
                                        break;
                                    case 'especes':
                                        $methode_paiement = 'Espèces';
                                        break;
                                }
                                echo $methode_paiement;
                                ?>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="commande_edit.php?id=<?php echo $commande['id']; ?>" class="btn btn-secondary">Modifier</a>
                            <a href="commande_view.php?id=<?php echo $commande['id']; ?>" class="btn btn-secondary">Détails</a>
                            <a href="commandes.php?delete=<?php echo $commande['id']; ?>" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette commande ?');">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center">Aucune commande trouvée</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
// Inclure le pied de page
require_once 'includes/footer.php';
?> 