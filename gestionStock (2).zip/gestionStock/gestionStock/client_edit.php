<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Définir le titre de la page
$titre = "Modifier un client";

// Vérifier si l'ID du client est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Rediriger vers la liste des clients si aucun ID n'est fourni
    $_SESSION['message'] = "Aucun client spécifié.";
    $_SESSION['message_type'] = "danger";
    header("Location: clients.php");
    exit;
}

$id = intval($_GET['id']);

// Récupérer les informations du client
try {
    $stmt = $connexion->prepare("SELECT * FROM clients WHERE id = ?");
    $stmt->execute([$id]);
    $client = $stmt->fetch();
    
    if (!$client) {
        // Rediriger si le client n'existe pas
        $_SESSION['message'] = "Client introuvable.";
        $_SESSION['message_type'] = "danger";
        header("Location: clients.php");
        exit;
    }
} catch (PDOException $e) {
    // Message d'erreur en cas d'échec de la récupération
    $_SESSION['message'] = "Erreur lors de la récupération des informations du client : " . $e->getMessage();
    $_SESSION['message_type'] = "danger";
    header("Location: clients.php");
    exit;
}

// Initialisation des variables avec les données existantes du client
$nom = $client['nom'];
$type = $client['type'];
$email = $client['email'] ?? '';
$telephone = $client['telephone'] ?? '';
$erreurs = [];

// Traitement du formulaire lorsqu'il est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et validation des données du formulaire
    $nom = trim($_POST['nom'] ?? '');
    $type = $_POST['type'] ?? 'particulier';
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    
    // Validation des champs obligatoires
    if (empty($nom)) {
        $erreurs[] = "Le nom du client est obligatoire.";
    }
    
    // Validation du type de client
    if ($type !== 'particulier' && $type !== 'entreprise') {
        $erreurs[] = "Le type de client n'est pas valide.";
    }
    
    // Validation de l'email (si fourni)
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreurs[] = "L'adresse email n'est pas valide.";
    }
    
    // Si aucune erreur, mise à jour du client dans la base de données
    if (empty($erreurs)) {
        try {
            $stmt = $connexion->prepare("
                UPDATE clients
                SET nom = ?, type = ?, email = ?, telephone = ?
                WHERE id = ?
            ");
            
            $stmt->execute([$nom, $type, $email ?: null, $telephone ?: null, $id]);
            
            // Message de succès
            $_SESSION['message'] = "Le client a été modifié avec succès.";
            $_SESSION['message_type'] = "success";
            
            // Redirection vers la liste des clients
            header("Location: clients.php");
            exit;
        } catch (PDOException $e) {
            // Message d'erreur en cas d'échec de la mise à jour
            $erreurs[] = "Erreur lors de la mise à jour du client : " . $e->getMessage();
        }
    }
}

// Inclure l'en-tête
require_once 'includes/header.php';
?>

<!-- Contenu principal -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Modifier un client</h2>
        <a href="clients.php" class="btn btn-secondary">Retour à la liste</a>
    </div>
    
    <?php if (!empty($erreurs)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($erreurs as $erreur): ?>
                    <li><?php echo $erreur; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form action="client_edit.php?id=<?php echo $id; ?>" method="POST">
        <div class="form-group">
            <label for="nom" class="form-label">Nom du client *</label>
            <input type="text" id="nom" name="nom" class="form-control" value="<?php echo htmlspecialchars($nom); ?>" required>
        </div>
        <div class="form-group">
            <label for="type" class="form-label">Type de client *</label>
            <select id="type" name="type" class="form-control" required>
                <option value="particulier" <?php echo $type === 'particulier' ? 'selected' : ''; ?>>Particulier</option>
                <option value="entreprise" <?php echo $type === 'entreprise' ? 'selected' : ''; ?>>Entreprise</option>
            </select>
        </div>
        <div class="form-group">
            <label for="email" class="form-label">Email</label>
            <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>">
        </div>
        <div class="form-group">
            <label for="telephone" class="form-label">Téléphone</label>
            <input type="tel" id="telephone" name="telephone" class="form-control" value="<?php echo htmlspecialchars($telephone); ?>">
        </div>
        <div class="form-group">
            <button type="submit" class="btn">Enregistrer les modifications</button>
            <a href="clients.php" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>

<?php
// Inclure le pied de page
require_once 'includes/footer.php';
?> 