<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Définir le titre de la page
$titre = "Ajouter une commande";

// Récupérer la liste des clients
try {
    $stmt = $connexion->query("SELECT id, nom FROM clients ORDER BY nom");
    $clients = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['message'] = "Erreur lors de la récupération des clients : " . $e->getMessage();
    $_SESSION['message_type'] = "danger";
    header("Location: commandes.php");
    exit;
}

// Récupérer la liste des produits
try {
    $stmt = $connexion->query("SELECT id, nom, reference, prix, quantite FROM produits WHERE quantite > 0 ORDER BY nom");
    $produits = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['message'] = "Erreur lors de la récupération des produits : " . $e->getMessage();
    $_SESSION['message_type'] = "danger";
    header("Location: commandes.php");
    exit;
}

// Initialisation des variables
$reference = 'CMD-' . date('YmdHis');
$client_id = '';
$date_commande = date('Y-m-d');
$statut = 'en_attente';
$methode_paiement = '';
$notes = '';
$produits_selectionnes = [];
$erreurs = [];

// Traitement du formulaire lorsqu'il est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et validation des données du formulaire
    $reference = trim($_POST['reference'] ?? '');
    $client_id = intval($_POST['client_id'] ?? 0);
    $date_commande = $_POST['date_commande'] ?? date('Y-m-d');
    $statut = $_POST['statut'] ?? 'en_attente';
    $methode_paiement = $_POST['methode_paiement'] ?? '';
    $notes = trim($_POST['notes'] ?? '');
    
    // Récupération des produits sélectionnés
    $produits_ids = $_POST['produit_id'] ?? [];
    $produits_quantites = $_POST['produit_quantite'] ?? [];
    $produits_prix = $_POST['produit_prix'] ?? [];
    
    // Validation des champs obligatoires
    if (empty($reference)) {
        $erreurs[] = "La référence de la commande est obligatoire.";
    }
    
    if (empty($client_id)) {
        $erreurs[] = "Le client est obligatoire.";
    }
    
    if (empty($date_commande)) {
        $erreurs[] = "La date de commande est obligatoire.";
    }
    
    // Vérifier que la date est valide
    if (!empty($date_commande) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_commande)) {
        $erreurs[] = "Le format de la date est invalide.";
    }
    
    // Vérifier que le statut est valide
    $statuts_valides = ['en_attente', 'en_cours', 'expediee', 'livree', 'annulee'];
    if (!in_array($statut, $statuts_valides)) {
        $erreurs[] = "Le statut de la commande n'est pas valide.";
    }
    
    // Vérifier que la méthode de paiement est valide
    $methodes_paiement_valides = ['', 'carte', 'virement', 'cheque', 'especes'];
    if (!in_array($methode_paiement, $methodes_paiement_valides)) {
        $erreurs[] = "La méthode de paiement n'est pas valide.";
    }
    
    // Vérifier qu'au moins un produit est sélectionné
    if (empty($produits_ids)) {
        $erreurs[] = "Vous devez sélectionner au moins un produit.";
    } else {
        // Construire le tableau des produits sélectionnés
        $montant_total = 0;
        for ($i = 0; $i < count($produits_ids); $i++) {
            $produit_id = intval($produits_ids[$i]);
            $quantite = intval($produits_quantites[$i]);
            $prix = floatval(str_replace(',', '.', $produits_prix[$i]));
            
            // Vérifier que le produit existe
            $stmt = $connexion->prepare("SELECT id, nom, quantite FROM produits WHERE id = ?");
            $stmt->execute([$produit_id]);
            $produit = $stmt->fetch();
            
            if (!$produit) {
                $erreurs[] = "Le produit sélectionné n'existe pas.";
                continue;
            }
            
            // Vérifier que la quantité est valide
            if ($quantite <= 0) {
                $erreurs[] = "La quantité doit être supérieure à zéro.";
                continue;
            }
            
            // Vérifier que le stock est suffisant
            if ($quantite > $produit['quantite']) {
                $erreurs[] = "Le stock est insuffisant pour le produit " . $produit['nom'] . " (disponible: " . $produit['quantite'] . ").";
                continue;
            }
            
            // Ajouter le produit à la liste
            $produits_selectionnes[] = [
                'id' => $produit_id,
                'quantite' => $quantite,
                'prix' => $prix,
                'total' => $quantite * $prix
            ];
            
            // Ajouter au montant total
            $montant_total += $quantite * $prix;
        }
    }
    
    // Si aucune erreur, ajout de la commande dans la base de données
    if (empty($erreurs)) {
        try {
            // Démarrer une transaction
            $connexion->beginTransaction();
            
            // Ajouter la commande
            $stmt = $connexion->prepare("
                INSERT INTO commandes (reference, client_id, date_commande, statut, montant_total, methode_paiement, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $reference,
                $client_id,
                $date_commande,
                $statut,
                $montant_total,
                $methode_paiement ?: null,
                $notes ?: null
            ]);
            
            $commande_id = $connexion->lastInsertId();
            
            // Ajouter les produits de la commande
            $stmt = $connexion->prepare("
                INSERT INTO commande_produits (commande_id, produit_id, quantite, prix_unitaire)
                VALUES (?, ?, ?, ?)
            ");
            
            foreach ($produits_selectionnes as $produit) {
                $stmt->execute([
                    $commande_id,
                    $produit['id'],
                    $produit['quantite'],
                    $produit['prix']
                ]);
                
                // Mettre à jour le stock du produit
                $connexion->prepare("
                    UPDATE produits
                    SET quantite = quantite - ?
                    WHERE id = ?
                ")->execute([
                    $produit['quantite'],
                    $produit['id']
                ]);
            }
            
            // Valider la transaction
            $connexion->commit();
            
            // Message de succès
            $_SESSION['message'] = "La commande a été ajoutée avec succès.";
            $_SESSION['message_type'] = "success";
            
            // Redirection vers la liste des commandes
            header("Location: commandes.php");
            exit;
        } catch (PDOException $e) {
            // Annuler la transaction en cas d'erreur
            $connexion->rollBack();
            
            // Message d'erreur en cas d'échec de l'ajout
            $erreurs[] = "Erreur lors de l'ajout de la commande : " . $e->getMessage();
        }
    }
}

// Inclure l'en-tête
require_once 'includes/header.php';
?>

<!-- Contenu principal -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Ajouter une commande</h2>
        <a href="commandes.php" class="btn btn-secondary">Retour à la liste</a>
    </div>
    
    <?php if (!empty($erreurs)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($erreurs as $erreur): ?>
                    <li><?php echo $erreur; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form action="commande_add.php" method="POST" id="commande-form">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
            <div>
                <h3>Informations de la commande</h3>
                <div class="form-group">
                    <label for="reference" class="form-label">Référence *</label>
                    <input type="text" id="reference" name="reference" class="form-control" value="<?php echo htmlspecialchars($reference); ?>" required>
                </div>
                <div class="form-group">
                    <label for="client_id" class="form-label">Client *</label>
                    <select id="client_id" name="client_id" class="form-control" required>
                        <option value="">Sélectionner un client</option>
                        <?php foreach ($clients as $client): ?>
                            <option value="<?php echo $client['id']; ?>" <?php echo $client_id == $client['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($client['nom']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date_commande" class="form-label">Date de commande *</label>
                    <input type="date" id="date_commande" name="date_commande" class="form-control" value="<?php echo htmlspecialchars($date_commande); ?>" required>
                </div>
            </div>
            <div>
                <h3>Détails supplémentaires</h3>
                <div class="form-group">
                    <label for="statut" class="form-label">Statut *</label>
                    <select id="statut" name="statut" class="form-control" required>
                        <option value="en_attente" <?php echo $statut === 'en_attente' ? 'selected' : ''; ?>>En attente</option>
                        <option value="en_cours" <?php echo $statut === 'en_cours' ? 'selected' : ''; ?>>En cours</option>
                        <option value="expediee" <?php echo $statut === 'expediee' ? 'selected' : ''; ?>>Expédiée</option>
                        <option value="livree" <?php echo $statut === 'livree' ? 'selected' : ''; ?>>Livrée</option>
                        <option value="annulee" <?php echo $statut === 'annulee' ? 'selected' : ''; ?>>Annulée</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="methode_paiement" class="form-label">Méthode de paiement</label>
                    <select id="methode_paiement" name="methode_paiement" class="form-control">
                        <option value="">Sélectionner une méthode</option>
                        <option value="carte" <?php echo $methode_paiement === 'carte' ? 'selected' : ''; ?>>Carte bancaire</option>
                        <option value="virement" <?php echo $methode_paiement === 'virement' ? 'selected' : ''; ?>>Virement</option>
                        <option value="cheque" <?php echo $methode_paiement === 'cheque' ? 'selected' : ''; ?>>Chèque</option>
                        <option value="especes" <?php echo $methode_paiement === 'especes' ? 'selected' : ''; ?>>Espèces</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="notes" class="form-label">Notes</label>
                    <textarea id="notes" name="notes" class="form-control" rows="4"><?php echo htmlspecialchars($notes); ?></textarea>
                </div>
            </div>
        </div>
        
        <h3>Produits de la commande</h3>
        <div id="produits-container">
            <table>
                <thead>
                    <tr>
                        <th>Produit *</th>
                        <th>Prix unitaire (€) *</th>
                        <th>Quantité *</th>
                        <th>Total (€)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="produits-tbody">
                    <tr>
                        <td>
                            <select name="produit_id[]" class="form-control produit-select" required>
                                <option value="">Sélectionner un produit</option>
                                <?php foreach ($produits as $produit): ?>
                                    <option value="<?php echo $produit['id']; ?>" data-prix="<?php echo $produit['prix']; ?>" data-stock="<?php echo $produit['quantite']; ?>">
                                        <?php echo htmlspecialchars($produit['nom']); ?> (Ref: <?php echo htmlspecialchars($produit['reference']); ?>, Stock: <?php echo $produit['quantite']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <input type="text" name="produit_prix[]" class="form-control produit-prix" readonly required>
                        </td>
                        <td>
                            <input type="number" name="produit_quantite[]" class="form-control produit-quantite" min="1" value="1" required>
                        </td>
                        <td>
                            <input type="text" class="form-control produit-total" readonly>
                        </td>
                        <td>
                            <button type="button" class="btn btn-danger btn-remove-produit">Supprimer</button>
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" style="text-align: right;"><strong>Total de la commande :</strong></td>
                        <td><input type="text" id="montant-total" class="form-control" readonly></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
            <button type="button" id="btn-add-produit" class="btn" style="margin-top: 1rem;">Ajouter un produit</button>
        </div>
        
        <div class="form-group" style="margin-top: 1.5rem;">
            <button type="submit" class="btn">Ajouter la commande</button>
            <a href="commandes.php" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>

<script>
    // Fonction pour mettre à jour le prix du produit
    function updateProductPrice(row) {
        const selectElement = row.querySelector('.produit-select');
        const priceInput = row.querySelector('.produit-prix');
        const quantityInput = row.querySelector('.produit-quantite');
        const totalInput = row.querySelector('.produit-total');
        
        if (selectElement.value) {
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const price = parseFloat(selectedOption.dataset.prix);
            const stock = parseInt(selectedOption.dataset.stock);
            
            priceInput.value = price.toFixed(2);
            
            // Limiter la quantité au stock disponible
            quantityInput.max = stock;
            if (parseInt(quantityInput.value) > stock) {
                quantityInput.value = stock;
            }
            
            // Mettre à jour le total
            const quantity = parseInt(quantityInput.value);
            totalInput.value = (price * quantity).toFixed(2);
        } else {
            priceInput.value = '';
            totalInput.value = '';
        }
        
        // Mettre à jour le total de la commande
        updateOrderTotal();
    }
    
    // Fonction pour mettre à jour le total de la commande
    function updateOrderTotal() {
        const totalInputs = document.querySelectorAll('.produit-total');
        let total = 0;
        
        totalInputs.forEach(input => {
            if (input.value) {
                total += parseFloat(input.value);
            }
        });
        
        document.getElementById('montant-total').value = total.toFixed(2);
    }
    
    // Fonction pour ajouter une ligne de produit
    function addProductRow() {
        const tbody = document.getElementById('produits-tbody');
        const firstRow = tbody.querySelector('tr');
        const newRow = firstRow.cloneNode(true);
        
        // Réinitialiser les valeurs
        newRow.querySelector('.produit-select').value = '';
        newRow.querySelector('.produit-prix').value = '';
        newRow.querySelector('.produit-quantite').value = '1';
        newRow.querySelector('.produit-total').value = '';
        
        // Ajouter la nouvelle ligne
        tbody.appendChild(newRow);
        
        // Ajouter les écouteurs d'événements
        setupRowEventListeners(newRow);
    }
    
    // Fonction pour supprimer une ligne de produit
    function removeProductRow(event) {
        const button = event.target;
        const row = button.closest('tr');
        const tbody = row.parentNode;
        
        // Ne pas supprimer la dernière ligne
        if (tbody.children.length > 1) {
            tbody.removeChild(row);
            updateOrderTotal();
        }
    }
    
    // Fonction pour configurer les écouteurs d'événements pour une ligne
    function setupRowEventListeners(row) {
        const selectElement = row.querySelector('.produit-select');
        const quantityInput = row.querySelector('.produit-quantite');
        const removeButton = row.querySelector('.btn-remove-produit');
        
        selectElement.addEventListener('change', () => updateProductPrice(row));
        quantityInput.addEventListener('change', () => updateProductPrice(row));
        removeButton.addEventListener('click', removeProductRow);
    }
    
    // Configurer les écouteurs d'événements pour les lignes existantes
    document.querySelectorAll('#produits-tbody tr').forEach(setupRowEventListeners);
    
    // Ajouter un écouteur pour le bouton d'ajout de produit
    document.getElementById('btn-add-produit').addEventListener('click', addProductRow);
    
    // Mettre à jour les prix au chargement de la page
    document.querySelectorAll('#produits-tbody tr').forEach(updateProductPrice);
</script>

<?php
// Inclure le pied de page
require_once 'includes/footer.php';
?> 