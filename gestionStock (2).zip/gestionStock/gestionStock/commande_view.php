<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Définir le titre de la page
$titre = "Détails de la commande";

// Vérifier si l'ID de la commande est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Rediriger vers la liste des commandes si aucun ID n'est fourni
    $_SESSION['message'] = "Aucune commande spécifiée.";
    $_SESSION['message_type'] = "danger";
    header("Location: commandes.php");
    exit;
}

$id = intval($_GET['id']);

// Récupérer les informations de la commande
try {
    $stmt = $connexion->prepare("
        SELECT c.*, cl.nom as client_nom, cl.email as client_email, cl.telephone as client_telephone, cl.type as client_type
        FROM commandes c
        JOIN clients cl ON c.client_id = cl.id
        WHERE c.id = ?
    ");
    $stmt->execute([$id]);
    $commande = $stmt->fetch();
    
    if (!$commande) {
        // Rediriger si la commande n'existe pas
        $_SESSION['message'] = "Commande introuvable.";
        $_SESSION['message_type'] = "danger";
        header("Location: commandes.php");
        exit;
    }
    
    // Récupérer les produits de la commande
    $stmt = $connexion->prepare("
        SELECT cp.*, p.nom as produit_nom, p.reference as produit_reference
        FROM commande_produits cp
        JOIN produits p ON cp.produit_id = p.id
        WHERE cp.commande_id = ?
    ");
    $stmt->execute([$id]);
    $produits_commande = $stmt->fetchAll();
    
} catch (PDOException $e) {
    // Message d'erreur en cas d'échec de la récupération
    $_SESSION['message'] = "Erreur lors de la récupération des informations de la commande : " . $e->getMessage();
    $_SESSION['message_type'] = "danger";
    header("Location: commandes.php");
    exit;
}

// Inclure l'en-tête
require_once 'includes/header.php';

// Formater le statut de la commande
$statut_classe = '';
$statut_texte = '';
switch ($commande['statut']) {
    case 'en_attente':
        $statut_classe = 'badge-warning';
        $statut_texte = 'En attente';
        break;
    case 'en_cours':
        $statut_classe = 'badge-warning';
        $statut_texte = 'En cours';
        break;
    case 'expediee':
        $statut_classe = 'badge-primary';
        $statut_texte = 'Expédiée';
        break;
    case 'livree':
        $statut_classe = 'badge-success';
        $statut_texte = 'Livrée';
        break;
    case 'annulee':
        $statut_classe = 'badge-danger';
        $statut_texte = 'Annulée';
        break;
}

// Formater la méthode de paiement
$methode_paiement = '';
if ($commande['methode_paiement']) {
    switch ($commande['methode_paiement']) {
        case 'carte':
            $methode_paiement = 'Carte bancaire';
            break;
        case 'virement':
            $methode_paiement = 'Virement';
            break;
        case 'cheque':
            $methode_paiement = 'Chèque';
            break;
        case 'especes':
            $methode_paiement = 'Espèces';
            break;
    }
}
?>

<!-- Contenu principal -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Détails de la commande <?php echo htmlspecialchars($commande['reference']); ?></h2>
        <div>
            <a href="commande_edit.php?id=<?php echo $id; ?>" class="btn">Modifier</a>
            <a href="commandes.php" class="btn btn-secondary">Retour à la liste</a>
        </div>
    </div>
    
    <!-- Informations de la commande -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
        <div>
            <h3>Informations de la commande</h3>
            <table>
                <tr>
                    <th style="width: 150px;">Référence :</th>
                    <td><?php echo htmlspecialchars($commande['reference']); ?></td>
                </tr>
                <tr>
                    <th>Date :</th>
                    <td><?php echo date('d/m/Y', strtotime($commande['date_commande'])); ?></td>
                </tr>
                <tr>
                    <th>Statut :</th>
                    <td><span class="badge <?php echo $statut_classe; ?>"><?php echo $statut_texte; ?></span></td>
                </tr>
                <tr>
                    <th>Montant total :</th>
                    <td><strong><?php echo number_format($commande['montant_total'], 2, ',', ' ') . ' €'; ?></strong></td>
                </tr>
                <tr>
                    <th>Paiement :</th>
                    <td><?php echo $methode_paiement ?: '-'; ?></td>
                </tr>
                <?php if (!empty($commande['notes'])): ?>
                <tr>
                    <th>Notes :</th>
                    <td><?php echo nl2br(htmlspecialchars($commande['notes'])); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
        
        <div>
            <h3>Informations du client</h3>
            <table>
                <tr>
                    <th style="width: 150px;">Nom :</th>
                    <td><?php echo htmlspecialchars($commande['client_nom']); ?></td>
                </tr>
                <tr>
                    <th>Type :</th>
                    <td>
                        <?php if ($commande['client_type'] === 'particulier'): ?>
                            <span class="badge badge-success">Particulier</span>
                        <?php else: ?>
                            <span class="badge badge-warning">Entreprise</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php if (!empty($commande['client_email'])): ?>
                <tr>
                    <th>Email :</th>
                    <td><?php echo htmlspecialchars($commande['client_email']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($commande['client_telephone'])): ?>
                <tr>
                    <th>Téléphone :</th>
                    <td><?php echo htmlspecialchars($commande['client_telephone']); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
    
    <!-- Produits de la commande -->
    <h3>Produits de la commande</h3>
    <table>
        <thead>
            <tr>
                <th>Produit</th>
                <th>Référence</th>
                <th>Prix unitaire</th>
                <th>Quantité</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($produits_commande) > 0): ?>
                <?php foreach ($produits_commande as $produit): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($produit['produit_nom']); ?></td>
                        <td><?php echo htmlspecialchars($produit['produit_reference']); ?></td>
                        <td><?php echo number_format($produit['prix_unitaire'], 2, ',', ' ') . ' €'; ?></td>
                        <td><?php echo $produit['quantite']; ?></td>
                        <td><?php echo number_format($produit['prix_unitaire'] * $produit['quantite'], 2, ',', ' ') . ' €'; ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="4" style="text-align: right;"><strong>Total :</strong></td>
                    <td><strong><?php echo number_format($commande['montant_total'], 2, ',', ' ') . ' €'; ?></strong></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center">Aucun produit dans cette commande</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
// Inclure le pied de page
require_once 'includes/footer.php';
?> 