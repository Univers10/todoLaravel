-- Création de la base de données si elle n'existe pas
CREATE DATABASE IF NOT EXISTS `gestion_stock` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `gestion_stock`;

-- Structure de la table `produits`
CREATE TABLE IF NOT EXISTS `produits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `reference` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `categorie` varchar(50) DEFAULT NULL,
  `prix` decimal(10,2) NOT NULL,
  `quantite` int(11) NOT NULL DEFAULT 0,
  `seuil_alerte` int(11) DEFAULT 10,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Structure de la table `clients`
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `type` enum('particulier','entreprise') NOT NULL DEFAULT 'particulier',
  `email` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `code_postal` varchar(10) DEFAULT NULL,
  `ville` varchar(50) DEFAULT NULL,
  `pays` varchar(50) DEFAULT 'France',
  `notes` text DEFAULT NULL,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Structure de la table `commandes`
CREATE TABLE IF NOT EXISTS `commandes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_commande` date NOT NULL,
  `statut` enum('en_attente','en_cours','expediee','livree','annulee') NOT NULL DEFAULT 'en_attente',
  `montant_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `methode_paiement` enum('carte','virement','cheque','especes') DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `commandes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Structure de la table `commande_produits`
CREATE TABLE IF NOT EXISTS `commande_produits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commande_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `commande_id` (`commande_id`),
  KEY `produit_id` (`produit_id`),
  CONSTRAINT `commande_produits_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commande_produits_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insertion de quelques données de test pour les produits
INSERT INTO `produits` (`nom`, `reference`, `description`, `categorie`, `prix`, `quantite`, `seuil_alerte`) VALUES
('Ordinateur portable', 'ORD-001', 'Ordinateur portable haute performance', 'Électronique', 899.99, 15, 5),
('Smartphone', 'SMART-001', 'Smartphone dernière génération', 'Électronique', 499.99, 8, 3),
('Imprimante', 'IMP-001', 'Imprimante multifonction', 'Fournitures', 199.99, 5, 2),
('T-shirt', 'TS-001', 'T-shirt coton bio', 'Vêtements', 19.99, 25, 10),
('Café', 'CAFE-001', 'Café en grains premium', 'Alimentation', 7.99, 50, 10);

-- Insertion de quelques données de test pour les clients
INSERT INTO `clients` (`nom`, `type`, `email`, `telephone`, `adresse`, `code_postal`, `ville`, `pays`) VALUES
('Jean Dupont', 'particulier', 'jean.dupont@example.com', '0612345678', '15 rue des Lilas', '75001', 'Paris', 'France'),
('Marie Martin', 'particulier', 'marie.martin@example.com', '0687654321', '8 avenue Victor Hugo', '69002', 'Lyon', 'France'),
('Entreprise ABC', 'entreprise', 'contact@abc.com', '0478123456', '120 rue de la République', '69003', 'Lyon', 'France');

-- Insertion de quelques données de test pour les commandes
INSERT INTO `commandes` (`reference`, `client_id`, `date_commande`, `statut`, `montant_total`, `methode_paiement`) VALUES
('CMD-001', 1, '2025-05-01', 'livree', 899.99, 'carte'),
('CMD-002', 2, '2025-05-02', 'en_cours', 499.99, 'virement'),
('CMD-003', 3, '2025-05-03', 'en_attente', 2499.95, 'cheque');

-- Insertion de quelques données de test pour les produits commandés
INSERT INTO `commande_produits` (`commande_id`, `produit_id`, `quantite`, `prix_unitaire`) VALUES
(1, 1, 1, 899.99),
(2, 2, 1, 499.99),
(3, 1, 2, 899.99),
(3, 3, 3, 199.99); 