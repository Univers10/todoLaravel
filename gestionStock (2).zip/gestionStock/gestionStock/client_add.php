<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Définir le titre de la page
$titre = "Ajouter un client";

// Initialisation des variables
$nom = '';
$type = 'particulier';
$email = '';
$telephone = '';
$erreurs = [];

// Traitement du formulaire lorsqu'il est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et validation des données du formulaire
    $nom = trim($_POST['nom'] ?? '');
    $type = $_POST['type'] ?? 'particulier';
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    
    // Validation des champs obligatoires
    if (empty($nom)) {
        $erreurs[] = "Le nom du client est obligatoire.";
    }
    
    // Validation du type de client
    if ($type !== 'particulier' && $type !== 'entreprise') {
        $erreurs[] = "Le type de client n'est pas valide.";
    }
    
    // Validation de l'email (si fourni)
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreurs[] = "L'adresse email n'est pas valide.";
    }
    
    // Si aucune erreur, ajout du client dans la base de données
    if (empty($erreurs)) {
        try {
            $stmt = $connexion->prepare("
                INSERT INTO clients (nom, type, email, telephone)
                VALUES (?, ?, ?, ?)
            ");
            
            $stmt->execute([$nom, $type, $email ?: null, $telephone ?: null]);
            
            // Message de succès
            $_SESSION['message'] = "Le client a été ajouté avec succès.";
            $_SESSION['message_type'] = "success";
            
            // Redirection vers la liste des clients
            header("Location: clients.php");
            exit;
        } catch (PDOException $e) {
            // Message d'erreur en cas d'échec de l'ajout
            $erreurs[] = "Erreur lors de l'ajout du client : " . $e->getMessage();
        }
    }
}

// Inclure l'en-tête
require_once 'includes/header.php';
?>

<!-- Contenu principal -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Ajouter un client</h2>
        <a href="clients.php" class="btn btn-secondary">Retour à la liste</a>
    </div>
    
    <?php if (!empty($erreurs)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($erreurs as $erreur): ?>
                    <li><?php echo $erreur; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form action="client_add.php" method="POST">
        <div class="form-group">
            <label for="nom" class="form-label">Nom du client *</label>
            <input type="text" id="nom" name="nom" class="form-control" value="<?php echo htmlspecialchars($nom); ?>" required>
        </div>
        <div class="form-group">
            <label for="type" class="form-label">Type de client *</label>
            <select id="type" name="type" class="form-control" required>
                <option value="particulier" <?php echo $type === 'particulier' ? 'selected' : ''; ?>>Particulier</option>
                <option value="entreprise" <?php echo $type === 'entreprise' ? 'selected' : ''; ?>>Entreprise</option>
            </select>
        </div>
        <div class="form-group">
            <label for="email" class="form-label">Email</label>
            <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>">
        </div>
        <div class="form-group">
            <label for="telephone" class="form-label">Téléphone</label>
            <input type="tel" id="telephone" name="telephone" class="form-control" value="<?php echo htmlspecialchars($telephone); ?>">
        </div>
        <div class="form-group">
            <button type="submit" class="btn">Ajouter le client</button>
            <a href="clients.php" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>

<?php
// Inclure le pied de page
require_once 'includes/footer.php';
?> 