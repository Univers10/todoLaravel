<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Vérifier si l'ID du produit est spécifié
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['message'] = "ID de produit non spécifié.";
    $_SESSION['message_type'] = "danger";
    header("Location: produits.php");
    exit;
}

$id = intval($_GET['id']);

// Initialiser les variables
$nom = '';
$reference = '';
$description = '';
$categorie = '';
$prix = '';
$quantite = '';
$seuil_alerte = 10;
$errors = [];

// Récupérer les données du produit
try {
    $stmt = $connexion->prepare("SELECT * FROM produits WHERE id = ?");
    $stmt->execute([$id]);
    $produit = $stmt->fetch();
    
    if (!$produit) {
        $_SESSION['message'] = "Produit introuvable.";
        $_SESSION['message_type'] = "danger";
        header("Location: produits.php");
        exit;
    }
    
    // Pré-remplir les champs avec les données existantes
    $nom = $produit['nom'];
    $reference = $produit['reference'];
    $description = $produit['description'];
    $categorie = $produit['categorie'];
    $prix = $produit['prix'];
    $quantite = $produit['quantite'];
    $seuil_alerte = $produit['seuil_alerte'];
} catch (PDOException $e) {
    $_SESSION['message'] = "Erreur lors de la récupération du produit : " . $e->getMessage();
    $_SESSION['message_type'] = "danger";
    header("Location: produits.php");
    exit;
}

// Traitement du formulaire de modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et validation des données
    $nom = trim($_POST['nom'] ?? '');
    $reference = trim($_POST['reference'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $categorie = trim($_POST['categorie'] ?? '');
    if ($categorie === 'Autre' && !empty($_POST['autre_categorie'])) {
        $categorie = trim($_POST['autre_categorie']);
    }
    $prix = floatval($_POST['prix'] ?? 0);
    $quantite = intval($_POST['quantite'] ?? 0);
    $seuil_alerte = intval($_POST['seuil_alerte'] ?? 10);
    
    // Validation des champs
    if (empty($nom)) {
        $errors[] = "Le nom du produit est obligatoire.";
    }
    
    if (!empty($reference) && $reference !== $produit['reference']) {
        // Vérifier si la référence existe déjà pour un autre produit
        $stmt = $connexion->prepare("SELECT id FROM produits WHERE reference = ? AND id != ?");
        $stmt->execute([$reference, $id]);
        if ($stmt->fetch()) {
            $errors[] = "Cette référence existe déjà. Veuillez en choisir une autre.";
        }
    }
    
    if ($prix <= 0) {
        $errors[] = "Le prix doit être supérieur à 0.";
    }
    
    if ($quantite < 0) {
        $errors[] = "La quantité ne peut pas être négative.";
    }
    
    if ($seuil_alerte < 0) {
        $errors[] = "Le seuil d'alerte ne peut pas être négatif.";
    }
    
    // Si aucune erreur, mettre à jour le produit
    if (empty($errors)) {
        try {
            $stmt = $connexion->prepare("
                UPDATE produits SET
                    nom = ?,
                    reference = ?,
                    description = ?,
                    categorie = ?,
                    prix = ?,
                    quantite = ?,
                    seuil_alerte = ?
                WHERE id = ?
            ");
            
            $result = $stmt->execute([
                $nom,
                $reference,
                $description,
                $categorie,
                $prix,
                $quantite,
                $seuil_alerte,
                $id
            ]);
            
            if ($result) {
                $_SESSION['message'] = "Le produit a été mis à jour avec succès.";
                $_SESSION['message_type'] = "success";
                
                // Rediriger vers la liste des produits
                header("Location: produits.php");
                exit;
            } else {
                $errors[] = "Une erreur est survenue lors de la mise à jour du produit.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur : " . $e->getMessage();
        }
    }
}

// Récupérer les catégories existantes pour la liste déroulante
$stmt = $connexion->query("SELECT DISTINCT categorie FROM produits ORDER BY categorie");
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un produit - Gestion de Stock</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --light: #f8fafc;
            --dark: #1e293b;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f1f5f9;
            color: var(--dark);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: var(--dark);
            color: white;
            padding: 1rem;
        }
        
        .sidebar-header {
            padding: 1rem 0;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 1rem;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            margin-bottom: 0.5rem;
        }
        
        .sidebar-menu a {
            display: block;
            padding: 0.75rem 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 0.25rem;
            transition: all 0.3s ease;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            padding: 1rem;
            overflow-y: auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .header h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        /* Card */
        .card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
        }
        
        /* Alert */
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 0.25rem;
        }
        
        .alert-danger {
            background-color: #fee2e2;
            color: #dc2626;
            border: 1px solid #fca5a5;
        }
        
        /* Forms */
        .form-group {
            margin-bottom: 1rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        
        .form-row {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .form-col {
            flex: 1;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #cbd5e1;
            border-radius: 0.25rem;
            font-size: 1rem;
        }
        
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        /* Buttons */
        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            font-weight: 500;
            text-align: center;
            border: none;
            border-radius: 0.25rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            margin-right: 0.25rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                margin-bottom: 1rem;
            }
            
            .form-row {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>GestionStock</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Tableau de bord</a></li>
                <li><a href="produits.php" class="active">Produits</a></li>
                <li><a href="clients.php">Clients</a></li>
                <li><a href="commandes.php">Commandes</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Modifier le produit</h1>
                <a href="produits.php" class="btn btn-primary">Retour à la liste</a>
            </div>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Informations du produit</div>
                </div>
                
                <form action="" method="post">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="nom">Nom du produit *</label>
                                <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($nom); ?>" required>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="reference">Référence (unique)</label>
                                <input type="text" id="reference" name="reference" value="<?php echo htmlspecialchars($reference); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="categorie">Catégorie</label>
                                <select id="categorie" name="categorie">
                                    <option value="">-- Sélectionner une catégorie --</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <?php if ($cat !== $categorie): ?>
                                            <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo ($categorie === $cat) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($cat); ?>
                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                    <?php if (in_array($categorie, $categories)): ?>
                                        <option value="<?php echo htmlspecialchars($categorie); ?>" selected>
                                            <?php echo htmlspecialchars($categorie); ?>
                                        </option>
                                    <?php endif; ?>
                                    <option value="Autre" <?php echo (!in_array($categorie, $categories) && $categorie != '') ? 'selected' : ''; ?>>Autre</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col" id="autre-categorie" style="display: <?php echo (!in_array($categorie, $categories) && $categorie != '') ? 'block' : 'none'; ?>;">
                            <div class="form-group">
                                <label for="autre-categorie-input">Autre catégorie</label>
                                <input type="text" id="autre-categorie-input" name="autre_categorie" value="<?php echo !in_array($categorie, $categories) ? htmlspecialchars($categorie) : ''; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="prix">Prix (€) *</label>
                                <input type="number" id="prix" name="prix" step="0.01" min="0" value="<?php echo htmlspecialchars($prix); ?>" required>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="quantite">Quantité en stock *</label>
                                <input type="number" id="quantite" name="quantite" min="0" value="<?php echo htmlspecialchars($quantite); ?>" required>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="seuil_alerte">Seuil d'alerte</label>
                                <input type="number" id="seuil_alerte" name="seuil_alerte" min="0" value="<?php echo htmlspecialchars($seuil_alerte); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description"><?php echo htmlspecialchars($description); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                        <a href="produits.php" class="btn btn-danger">Annuler</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Afficher/masquer le champ "Autre catégorie" en fonction de la sélection
        document.getElementById('categorie').addEventListener('change', function() {
            var autreCategorie = document.getElementById('autre-categorie');
            if (this.value === 'Autre') {
                autreCategorie.style.display = 'block';
            } else {
                autreCategorie.style.display = 'none';
            }
        });
    </script>
</body>
</html> 