<?php
// Démarrer la session
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'config/database.php';

// Traitement de la suppression d'un produit
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    try {
        // Vérifier si le produit existe
        $stmt = $connexion->prepare("SELECT * FROM produits WHERE id = ?");
        $stmt->execute([$id]);
        $produit = $stmt->fetch();
        
        if ($produit) {
            // Supprimer le produit
            $stmt = $connexion->prepare("DELETE FROM produits WHERE id = ?");
            $stmt->execute([$id]);
            
            // Message de succès
            $_SESSION['message'] = "Le produit a été supprimé avec succès.";
            $_SESSION['message_type'] = "success";
        } else {
            // Message d'erreur si le produit n'existe pas
            $_SESSION['message'] = "Produit introuvable.";
            $_SESSION['message_type'] = "danger";
        }
    } catch (PDOException $e) {
        // Message d'erreur en cas d'échec de la suppression
        $_SESSION['message'] = "Erreur lors de la suppression du produit : " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }
    
    // Rediriger pour éviter la soumission du formulaire en cas de rafraîchissement de la page
    header("Location: produits.php");
    exit;
}

// Traitement de la recherche et des filtres
$search = isset($_GET['search']) ? $_GET['search'] : '';
$categorie = isset($_GET['categorie']) ? $_GET['categorie'] : '';
$stock = isset($_GET['stock']) ? $_GET['stock'] : '';

// Construction de la requête avec les filtres
$sql = "SELECT * FROM produits WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (nom LIKE ? OR reference LIKE ? OR description LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if (!empty($categorie)) {
    $sql .= " AND categorie = ?";
    $params[] = $categorie;
}

if (!empty($stock)) {
    switch ($stock) {
        case 'low':
            $sql .= " AND quantite <= seuil_alerte AND quantite > 0";
            break;
        case 'out':
            $sql .= " AND quantite = 0";
            break;
        case 'available':
            $sql .= " AND quantite > seuil_alerte";
            break;
    }
}

$sql .= " ORDER BY id DESC";

// Exécuter la requête
$stmt = $connexion->prepare($sql);
$stmt->execute($params);
$produits = $stmt->fetchAll();

// Récupérer toutes les catégories pour le filtre
$stmt = $connexion->query("SELECT DISTINCT categorie FROM produits ORDER BY categorie");
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Produits - Gestion de Stock</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --light: #f8fafc;
            --dark: #1e293b;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f1f5f9;
            color: var(--dark);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: var(--dark);
            color: white;
            padding: 1rem;
        }
        
        .sidebar-header {
            padding: 1rem 0;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 1rem;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            margin-bottom: 0.5rem;
        }
        
        .sidebar-menu a {
            display: block;
            padding: 0.75rem 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 0.25rem;
            transition: all 0.3s ease;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            padding: 1rem;
            overflow-y: auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .header h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        /* Card */
        .card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        /* Alert */
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 0.25rem;
        }
        
        .alert-success {
            background-color: #dcfce7;
            color: #16a34a;
            border: 1px solid #86efac;
        }
        
        .alert-danger {
            background-color: #fee2e2;
            color: #dc2626;
            border: 1px solid #fca5a5;
        }
        
        /* Forms */
        .form-group {
            margin-bottom: 1rem;
        }
        
        .search-container {
            margin-bottom: 1rem;
        }
        
        .search-input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #cbd5e1;
            border-radius: 0.25rem;
            font-size: 1rem;
        }
        
        .filter-container {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .filter-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .filter-group label {
            margin-bottom: 0;
            white-space: nowrap;
        }
        
        .filter-group select {
            padding: 0.5rem;
            border: 1px solid #cbd5e1;
            border-radius: 0.25rem;
            font-size: 1rem;
        }
        
        /* Table */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead th {
            background-color: #f8fafc;
            text-align: left;
            padding: 0.75rem;
            font-weight: 600;
        }
        
        tbody td {
            padding: 0.75rem;
            border-top: 1px solid #e2e8f0;
        }
        
        tbody tr:hover {
            background-color: #f1f5f9;
        }
        
        /* Badges */
        .badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-success {
            background-color: #dcfce7;
            color: #16a34a;
        }
        
        .badge-warning {
            background-color: #fef3c7;
            color: #d97706;
        }
        
        .badge-danger {
            background-color: #fee2e2;
            color: #dc2626;
        }
        
        /* Buttons */
        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            font-weight: 500;
            text-align: center;
            border: none;
            border-radius: 0.25rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            margin-right: 0.25rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-success {
            background-color: var(--success);
            color: white;
        }
        
        .d-flex {
            display: flex;
        }
        
        .gap-2 {
            gap: 0.5rem;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                margin-bottom: 1rem;
            }
            
            .filter-container {
                flex-direction: column;
            }
            
            .filter-group {
                width: 100%;
            }
            
            .d-flex {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .btn {
                width: 100%;
                margin-right: 0;
                margin-bottom: 0.25rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>GestionStock</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php">Tableau de bord</a></li>
                <li><a href="produits.php" class="active">Produits</a></li>
                <li><a href="clients.php">Clients</a></li>
                <li><a href="commandes.php">Commandes</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Gestion des Produits</h1>
                <a href="produit_add.php" class="btn btn-primary">Ajouter un produit</a>
            </div>
            
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <form action="" method="get">
                    <div class="search-container">
                        <input type="text" name="search" class="search-input" placeholder="Rechercher un produit..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-container">
                        <div class="filter-group">
                            <label for="categorie">Catégorie:</label>
                            <select id="categorie" name="categorie">
                                <option value="">Toutes</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo ($categorie === $cat) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label for="stock">Stock:</label>
                            <select id="stock" name="stock">
                                <option value="">Tous</option>
                                <option value="low" <?php echo ($stock === 'low') ? 'selected' : ''; ?>>Faible (< seuil)</option>
                                <option value="out" <?php echo ($stock === 'out') ? 'selected' : ''; ?>>Épuisé</option>
                                <option value="available" <?php echo ($stock === 'available') ? 'selected' : ''; ?>>Disponible</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Filtrer</button>
                        <a href="produits.php" class="btn btn-secondary">Réinitialiser</a>
                    </div>
                </form>
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Référence</th>
                            <th>Catégorie</th>
                            <th>Prix</th>
                            <th>Quantité</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($produits)): ?>
                            <tr>
                                <td colspan="8" style="text-align: center;">Aucun produit trouvé.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($produits as $produit): ?>
                                <tr>
                                    <td><?php echo $produit['id']; ?></td>
                                    <td><?php echo htmlspecialchars($produit['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($produit['reference']); ?></td>
                                    <td><?php echo htmlspecialchars($produit['categorie']); ?></td>
                                    <td><?php echo number_format($produit['prix'], 2, ',', ' '); ?> €</td>
                                    <td><?php echo $produit['quantite']; ?></td>
                                    <td>
                                        <?php
                                        if ($produit['quantite'] == 0) {
                                            echo '<span class="badge badge-danger">Épuisé</span>';
                                        } elseif ($produit['quantite'] <= $produit['seuil_alerte']) {
                                            echo '<span class="badge badge-warning">Stock faible</span>';
                                        } else {
                                            echo '<span class="badge badge-success">En stock</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="produit_view.php?id=<?php echo $produit['id']; ?>" class="btn btn-primary">Détails</a>
                                            <a href="produit_edit.php?id=<?php echo $produit['id']; ?>" class="btn btn-success">Modifier</a>
                                            <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $produit['id']; ?>)" class="btn btn-danger">Supprimer</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        function confirmDelete(id) {
            if (confirm("Êtes-vous sûr de vouloir supprimer ce produit ?")) {
                window.location.href = "produits.php?delete=" + id;
            }
        }
    </script>
</body>
</html> 